This is a minimal standalone portable version of python 3.12.9
from winpython
https://github.com/winpython/winpython/releases/tag/13.1.202502222final
Winpython64-3.12.9.0dot.zip
Includes tkinter
Extract to temp folder.  And only keep the python folder from the package. 
Excluding scripts, notebooks and other non python program files.
In the python folder, can also exclude doc sub folder.